using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(CapsuleCollider))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;

    [Header("Checkpoint")]
    [SerializeField] private Transform startingPoint;

    private Rigidbody rb;
    private Vector3 movement;

    private Vector3 checkpointPosition;
    private Quaternion checkpointRotation;

    private bool canMove = true;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();

        rb.freezeRotation = true;
    }

    private void Start()
    {
        if (startingPoint != null)
        {
            checkpointPosition = startingPoint.position;
            checkpointRotation = startingPoint.rotation;
        }
        else
        {
            checkpointPosition = transform.position;
            checkpointRotation = transform.rotation;
        }

        Debug.Log("[PlayerController] Neko is ready!");
    }

    private void Update()
    {
        if (!canMove) return;

        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");

        movement = new Vector3(h, 0f, v).normalized;
    }

    private void FixedUpdate()
    {
        if (!canMove) return;

        Vector3 velocity = rb.linearVelocity;

        rb.linearVelocity = new Vector3(
            movement.x * moveSpeed,
            velocity.y,
            movement.z * moveSpeed
        );
    }

    public void Respawn()
    {
        movement = Vector3.zero;
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        rb.position = checkpointPosition;
        rb.rotation = checkpointRotation;

        Debug.Log("[PlayerController] Neko respawned!");
    }

    public void SetCheckpoint(Transform checkpoint)
    {
        if (checkpoint == null) return;

        checkpointPosition = checkpoint.position;
        checkpointRotation = checkpoint.rotation;

        Debug.Log("[PlayerController] New checkpoint saved!");
    }

    public void SetMovementEnabled(bool enabled)
    {
        canMove = enabled;
        movement = Vector3.zero;

        if (!enabled && rb != null)
        {
            rb.linearVelocity = Vector3.zero;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Orb"))
        {
            Destroy(other.gameObject);

            if (GameManager.Instance != null)
            {
                GameManager.Instance.Collect();
            }
        }
    }
}
