using UnityEngine;

public class Hazard : MonoBehaviour
{
    [Header("Hazard Settings")]
    [SerializeField] private float respawnDelay = 0.2f;

    private bool playerHit = false;

    private void OnTriggerEnter(Collider other)
    {
        if (playerHit) return;

        PlayerController player =
            other.GetComponentInParent<PlayerController>();

        if (player != null)
        {
            playerHit = true;

            Debug.Log("[Hazard] Neko touched: " + gameObject.name);

            player.Respawn();

            Invoke(nameof(ResetHazard), respawnDelay);
        }
    }

    private void ResetHazard()
    {
        playerHit = false;
    }
}
